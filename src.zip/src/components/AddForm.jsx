import React from 'react';
import AddDetails from './AddDetails';

const AddForm = () => {
  return (
    <div>
       <table style={{ width: '100%', backgroundColor: '#452b93' }} cellspacing="0" cellpadding="0">
      <tr>
        <td className="row-half-8"><span>HANDLING UNITS (H/U)</span></td>
        <td className="row-half-8"><span>H/U PKG. TYPE</span></td>
        <td className="row-half-3"><span>PIECES</span></td>
        <td className="row-half-4 orange-4"><span>HM (X)</span></td>
        <td className="row-half-46"><span>KIND OF PACKAGE, DESCRIPTION OF ARTICLES, SPECIAL MARKS AND EXCEPTIONS (subject to correction)</span></td>
        <td className="row-half-10"><span>WEIGHT IN LBS</span></td>
        <td className="row-half-12 white-border"><span>NMFC ITEM #</span></td>    
        <td className="row-half-4"><span>CLASS</span></td>
        <td className="row-half-4"><span>CUBE</span></td>  
      </tr>
      <tr>
  <td className="row-half-8 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-8 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-4 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-4 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-46 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-10 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-12 blue-border"><input type="text" className="same-input" /></td>    
  <td className="row-half-4 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-4 blue-border"><input type="text" className="same-input" /></td>  
</tr>
<tr>
  <td className="row-half-8 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-8 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-4 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-4 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-46 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-10 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-12 blue-border"><input type="text" className="same-input" /></td>    
  <td className="row-half-4 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-4 blue-border"><input type="text" className="same-input" /></td>  
</tr>
<tr>
  <td className="row-half-8 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-8 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-4 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-4 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-46 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-10 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-12 blue-border"><input type="text" className="same-input" /></td>    
  <td className="row-half-4 blue-border"><input type="text" className="same-input" /></td>
  <td className="row-half-4 blue-border"><input type="text" className="same-input" /></td>  
</tr>
<tr>
          <td className="row-half-8 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-8 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-4 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-4 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-46 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-10 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-12 blue-border"><input type="text" className="same-input"></input></td>    
          <td className="row-half-4 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-4 blue-border"><input type="text" className="same-input"></input></td>  
        </tr>
        <tr>
          <td className="row-half-8 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-8 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-4 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-4 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-46 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-10 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-12 blue-border"><input type="text" className="same-input"></input></td>    
          <td className="row-half-4 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-4 blue-border"><input type="text" className="same-input"></input></td>  
        </tr>
        <tr>
          <td className="row-half-8 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-8 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-4 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-4 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-46 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-10 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-12 blue-border"><input type="text" className="same-input"></input></td>    
          <td className="row-half-4 blue-border"><input type="text" className="same-input"></input></td>
          <td className="row-half-4 blue-border"><input type="text" className="same-input"></input></td>
          </tr>


      </table>
    </div>
  )
}

export default AddForm
